# Mongoose with STM32, FreeRTOS kernel and FreeRTOS-TCP network stack

The `-DMG_ARCH=MG_ARCH_FREERTOS_TCP` compilation flag enables FreeRTOS+TCP support.