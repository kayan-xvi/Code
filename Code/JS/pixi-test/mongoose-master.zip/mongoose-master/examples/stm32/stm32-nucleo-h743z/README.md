See detailed tutorial at https://mongoose.ws/tutorials/stm32-nucleo-h743z/
