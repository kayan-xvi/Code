See detailed tutorial at https://mongoose.ws/tutorials/captive-dns-portal/
