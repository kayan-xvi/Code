See detailed tutorial at https://mongoose.ws/tutorials/file-uploads/
