See detailed tutorial at https://mongoose.ws/tutorials/json-rpc-over-websocket/
